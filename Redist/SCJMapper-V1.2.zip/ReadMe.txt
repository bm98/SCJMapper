SC Joystick Mapper V 1.2 
(c) Cassini - 10-June-2014

Contains 4 files:

SCJMapper.exe                The program
MappingVars.csv              The default actions - MUST be in the same folder as the Exe file
SCJMapper_QGuide V1.2.pdf    Quick Guide
ReadMe.txt                   This file

Read the Guide first RTFM ;-)
Put all files into one folder and hit SCJMapper.exe to run it

Scanned for viruses before packing... 
cassini@burri-web.org

Changelog:
V 1.0 initial 
V 1.1 
- fixed issue with less than 3 joysticks attached
V 1.2
- added support for rebinding xboxpad and ps3pad
- added Find 1st  for a Control
- fixed Hat direction not maintained as last Control used
- some GUI refinements
- Update of the Guide (incl MappingVar.csv format)
MappingVar file
- added commands that where missing
- changed from keyboard to xboxpad rebinding where possible to leave kbd intact
