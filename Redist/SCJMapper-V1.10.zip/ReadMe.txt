SC Joystick Mapper V 1.0 
(c) Cassini - 09-June-2014

Contains 4 files:

SCJMapper.exe           The program
MappingVars.csv         The default actions - MUST be in the same folder as the Exe file
SCJMapper_QGuide.pdf    Quick Guide
ReadMe.txt              This file

Read the Guide first RTFM ;-)
Put all files into one folder and hit SCJMapper.exe to run it

Scanned for viruses before packing... 
cassini@burri-web.org

